﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExampleClass : MonoBehaviour {
	public int myInt;
	[ColorLineAttribute("Green")]
	public GameObject myObject;
}
