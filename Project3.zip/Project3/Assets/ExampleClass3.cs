﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExampleClass3 : MonoBehaviour {
	[VectorScaleAttribute(-100, 100)]
	public Vector3 myVector3;
}