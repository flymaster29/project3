﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class SpriteShowAttribute : PropertyAttribute {

	public GameObject myobj;
	public int height, width;
	public SpriteShowAttribute(int pHeight, int pWidth) {
		this.height = pHeight;
		this.width = pWidth;
	}

}

[CustomPropertyDrawer (typeof (SpriteShowAttribute))]
public class SpriteObjDrawer : PropertyDrawer {
	Sprite sprite;
	Texture2D texture;
	bool entered =false;
	Sprite myObj;

	public override float GetPropertyHeight(SerializedProperty property, GUIContent label) {
		SpriteShowAttribute spriteAttribute = attribute as SpriteShowAttribute;
		return spriteAttribute.height + 25;
	}


	public override void OnGUI(Rect pos, SerializedProperty prop, GUIContent label) {
		Debug.Log ("Enter2");
		SpriteShowAttribute spriteAttribute = attribute as SpriteShowAttribute;
		if(!entered)
		myObj = (Sprite)prop.objectReferenceValue;

		Rect newPos = new Rect(pos.x, pos.y + 20, spriteAttribute.width, spriteAttribute.height);
		//EditorGUILayout.BeginVertical ();
		GUIStyle myTempStyle = new GUIStyle (GUI.skin.label);
		EditorGUI.LabelField (pos, "Image", myTempStyle);
		if (myObj) {
			texture = myObj.texture;
			EditorGUI.DrawPreviewTexture (newPos, texture);
		} else {
			prop.objectReferenceValue = (Sprite)EditorGUI.ObjectField(pos, prop.objectReferenceValue, typeof(Sprite), allowSceneObjects:true);
		}
		entered = true;
		Debug.Log ("Terrory");
    }
 }