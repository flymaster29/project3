﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExampleClass2 : MonoBehaviour {
	[SpriteShowAttribute(250,250)]
	public Sprite mySprite;
}