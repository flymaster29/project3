﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;


public class VectorScaleAttribute : PropertyAttribute {
	public int minVal;
	public int maxVal;

	public VectorScaleAttribute(int pMinVal, int pMaxVal) {
		this.minVal = pMinVal;
		this.maxVal = pMaxVal;
	}

}

[CustomPropertyDrawer(typeof(VectorScaleAttribute))]
public class VectorScaleDrawer: PropertyDrawer {
	float myFloatX, myFloatY, myFloatZ;
	Vector3 thisVector = new Vector3(0,0,0);
	
	public override float GetPropertyHeight(SerializedProperty property, GUIContent label) {
		return 100;
	}

	public override void OnGUI(Rect position, SerializedProperty property, GUIContent label) {
		VectorScaleAttribute vectorScaleAttribute = attribute as VectorScaleAttribute;

		Rect drawPosition = position;
		thisVector = property.vector3Value;
		GUI.enabled =false;
		EditorGUI.PropertyField (drawPosition, property, label, true);
		GUI.enabled =true;

		drawPosition.y += 20;
		drawPosition.height = 20;

		thisVector.x = EditorGUI.Slider (drawPosition, "X", thisVector.x, vectorScaleAttribute.minVal, vectorScaleAttribute.maxVal);
		drawPosition.y += 20;
		thisVector.y = EditorGUI.Slider (drawPosition, "Y", thisVector.y, vectorScaleAttribute.minVal, vectorScaleAttribute.maxVal);
		drawPosition.y += 20;
		thisVector.z = EditorGUI.Slider (drawPosition, "Z", thisVector.z, vectorScaleAttribute.minVal, vectorScaleAttribute.maxVal);

		property.vector3Value = thisVector;
		Debug.Log ("EntedMe");
		thisVector = property.vector3Value;
	}
}