﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;


public class ColorLineAttribute : PropertyAttribute {
	public Color tempColor = Color.black;
	public ColorLineAttribute(string color) {


		switch (color.ToLower()) {
		case "black" :
			tempColor = Color.black;
			break;
		case "blue" :
			tempColor = Color.blue;
			break;
		case "clear" :
			tempColor = Color.clear;
			break;
		case "cyan" :
			tempColor = Color.cyan;
			break;
		case "gray":
			tempColor = Color.gray;
			break;
		case "green" :
			tempColor = Color.green;
			break;
		case "grey" :
			tempColor = Color.grey;
			break;
		case "magenta" :
			tempColor = Color.magenta;
			break;
		case "red" :
			tempColor = Color.red;
			break;
		case "white":
			tempColor = Color.white;
			break;
		case "yellow":
			tempColor = Color.yellow;
			break;	
		}
	}
	/*
	public static Color GetColor() {
		return tempColor;
	}
	*/
}

[CustomPropertyDrawer(typeof(ColorLineAttribute))]
public class ColorLineDrawer: DecoratorDrawer {


	public override float GetHeight() {
		return 15;
	}

	public override void OnGUI(Rect position) {
		ColorLineAttribute obj = attribute as ColorLineAttribute;
		Color color = obj.tempColor;
		//GUIStyle myStyle = GUI.skin.GetStyle ("Label");
		GUIStyle randomStyle = new GUIStyle(GUI.skin.GetStyle ("Label"));
		//myStyle2. = Color.blue;
		randomStyle.alignment = TextAnchor.UpperLeft;
		randomStyle.fontStyle = FontStyle.Bold;
		randomStyle.normal.textColor = color;
		randomStyle.fontSize = 6;
		string tempString = 
			"__________________________________________" + 
			"__________________________________________" + 
			"__________________________________________" +
			"__________________________________________" +
			"__________________________________________" +
			"__________________________________________" +
			"__________________________________________" +
			"__________________________________________" +
			"__________________________________________";

		EditorGUI.LabelField(position, tempString, randomStyle);
		Debug.Log ("Enter");
		//base.OnGUI (position);
	}
}
